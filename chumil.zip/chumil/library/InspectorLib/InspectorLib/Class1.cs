﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectorLib
{
    public class FunctionInsp
    {
        string name = "Автоинспекция г.Чита";
        string Gname = "Васильев Василий Иванович";
        string[] nameS;
        string[] nameS1 =  { "Иванов И.И"," Зиронов Т.А"," Миронов А.В"," Васильев В.И" };
    public string GetInspector()
        {
            return "Инспектор - " + Gname;//возвращает ФИО организации
        }
        public string GetCarInspection()
        {
            return "Название - " + name;//вовзращает название организации и место         
        }
    }
}
